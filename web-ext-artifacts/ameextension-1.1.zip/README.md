# AmeExtension
Extract vocabulary information from jisho with a single click and downloads it as a txt file, json file or as an anki deck.

https://addons.mozilla.org/en-US/firefox/addon/ameextension/
