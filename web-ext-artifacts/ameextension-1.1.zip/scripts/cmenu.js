browser.contextMenus.create(
  {
    id: "jisho-selection",
    title: browser.i18n.getMessage("contextMenuItemSelectionLogger"),
    contexts: ["selection"],
  },
  onCreated
);

browser.contextMenus.onClicked.addListener((info, tab) => {
  if(info.menuItemId != "jisho-selection") {
      return
  }
    
});
